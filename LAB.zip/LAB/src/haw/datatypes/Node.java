package haw.datatypes;

public interface Node {
    public abstract int getKey();
}
